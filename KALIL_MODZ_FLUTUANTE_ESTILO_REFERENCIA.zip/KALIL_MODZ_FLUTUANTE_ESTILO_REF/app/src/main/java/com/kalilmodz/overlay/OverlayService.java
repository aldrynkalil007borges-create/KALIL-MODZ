package com.kalilmodz.overlay;
import android.app.Service;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.graphics.Typeface;
import android.os.Build;
import android.os.IBinder;
import android.view.*;
import android.widget.*;
public class OverlayService extends Service {
 WindowManager wm; View panel; WindowManager.LayoutParams lp; LinearLayout body; boolean minimized=false;
 int cyan=0xFF00B9F2, dark=0xFF0B1019, card=0xFF1B2431;
 TextView txt(String s,int size,int color){TextView t=new TextView(this);t.setText(s);t.setTextSize(size);t.setTextColor(color);t.setPadding(10,9,10,9);return t;}
 TextView row(String s){TextView t=txt("□   "+s,14,Color.WHITE);t.setBackgroundColor(card);LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2);p.setMargins(3,4,3,4);body.addView(t,p);t.setOnClickListener(v->{t.setText(t.getText().toString().startsWith("□")?"☑   "+s:"□   "+s);});return t;}
 @Override public void onCreate(){super.onCreate();wm=(WindowManager)getSystemService(WINDOW_SERVICE);
  int type=Build.VERSION.SDK_INT>=26?WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY:WindowManager.LayoutParams.TYPE_PHONE;
  lp=new WindowManager.LayoutParams(310,WindowManager.LayoutParams.WRAP_CONTENT,type,WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,PixelFormat.TRANSLUCENT);
  lp.gravity=Gravity.TOP|Gravity.RIGHT;lp.x=12;lp.y=100;
  LinearLayout outer=new LinearLayout(this);outer.setOrientation(1);outer.setBackgroundColor(dark);
  TextView header=txt("KALIL MODZ  •  PAINEL      −   ×",16,Color.WHITE);header.setTypeface(null,Typeface.BOLD);header.setBackgroundColor(0xFF009ED3);outer.addView(header);
  LinearLayout content=new LinearLayout(this);content.setOrientation(0);outer.addView(content);
  LinearLayout rail=new LinearLayout(this);rail.setOrientation(1);rail.setBackgroundColor(0xFF101722);content.addView(rail,new LinearLayout.LayoutParams(52,-1));
  body=new LinearLayout(this);body.setOrientation(1);body.setPadding(5,5,5,5);content.addView(body,new LinearLayout.LayoutParams(0,-2,1));
  String[] icons={"⊕","◉","⚙","▣"};String[] tabs={"MIRA","VISUAL","AJUSTES","INFO"};
  for(int i=0;i<icons.length;i++){final int n=i;TextView b=txt(icons[i],22,Color.WHITE);b.setGravity(Gravity.CENTER);rail.addView(b,new LinearLayout.LayoutParams(-1,56));b.setOnClickListener(v->showTab(n));}
  showTab(0);
  header.setOnTouchListener(new View.OnTouchListener(){int x,y;float sx,sy;public boolean onTouch(View v,MotionEvent e){if(e.getAction()==0){x=lp.x;y=lp.y;sx=e.getRawX();sy=e.getRawY();return true;}if(e.getAction()==2){lp.x=x+(int)(sx-e.getRawX());lp.y=y+(int)(e.getRawY()-sy);wm.updateViewLayout(panel,lp);return true;}return true;}});
  header.setOnClickListener(v->{});panel=outer;wm.addView(panel,lp);
  header.setOnLongClickListener(v->{stopSelf();return true;});
 }
 void showTab(int n){body.removeAllViews();if(n==0){body.addView(txt("FUNÇÕES DE MIRA",15,cyan));row("Mira de treino — prévia");body.addView(txt("Zona demonstrativa",13,Color.LTGRAY));row("Cabeça (prévia)");row("Pescoço (prévia)");row("Peito (prévia)");}else if(n==1){body.addView(txt("VISUAL",15,cyan));row("Painel compacto");row("Tema azul e preto");row("Prévia de círculo +");}else if(n==2){body.addView(txt("AJUSTES",15,cyan));body.addView(txt("Sensibilidade de treino",14,Color.WHITE));SeekBar s=new SeekBar(this);s.setMax(200);s.setProgress(95);body.addView(s);body.addView(txt("Controle visual demonstrativo",12,Color.LTGRAY));}else{body.addView(txt("KALIL MODZ",16,cyan));body.addView(txt("Interface demonstrativa flutuante. Não altera o jogo nem automatiza ações.",13,Color.WHITE));}
  TextView close=txt("FECHAR PAINEL",13,cyan);body.addView(close);close.setOnClickListener(v->stopSelf());
 }
 @Override public void onDestroy(){super.onDestroy();if(panel!=null){wm.removeView(panel);panel=null;}}
 @Override public IBinder onBind(Intent i){return null;}
}
