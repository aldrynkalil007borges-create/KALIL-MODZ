package com.kalilmodz.overlay;
import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.widget.*;
public class MainActivity extends Activity {
 @Override public void onCreate(Bundle b) {
  super.onCreate(b);
  LinearLayout root=new LinearLayout(this); root.setOrientation(1); root.setPadding(28,42,28,28); root.setBackgroundColor(0xFF10141C);
  TextView title=new TextView(this); title.setText("KALIL MODZ"); title.setTextColor(0xFF00B9F2); title.setTextSize(27); title.setTypeface(null,1); root.addView(title);
  TextView info=new TextView(this); info.setText("\nPainel flutuante com visual compacto azul e preto.\n\nPermita a sobreposição e toque para abrir o painel sobre outros aplicativos.\n\nAs opções são demonstrações visuais: não modificam o Free Fire, não injetam código e não automatizam a mira."); info.setTextColor(-1); info.setTextSize(15); root.addView(info);
  Button perm=new Button(this); perm.setText("PERMITIR SOBREPOSIÇÃO"); root.addView(perm);
  Button open=new Button(this); open.setText("ABRIR PAINEL FLUTUANTE"); root.addView(open);
  perm.setOnClickListener(v->{if(!Settings.canDrawOverlays(this)) startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:"+getPackageName())));});
  open.setOnClickListener(v->{if(Settings.canDrawOverlays(this)) startService(new Intent(this,OverlayService.class)); else perm.performClick();});
  setContentView(root);
 }
}
